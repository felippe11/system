# Renomeando o arquivo original de rotas para routes_original.py
from routes import routes

# Re-exportar o blueprint de rotas para compatibilidade
routes = routes
