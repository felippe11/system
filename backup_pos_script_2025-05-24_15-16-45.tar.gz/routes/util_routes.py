from flask import Blueprint

util_routes = Blueprint('util_routes', __name__)
