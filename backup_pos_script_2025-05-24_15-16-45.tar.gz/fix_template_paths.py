#!/usr/bin/env python3
"""
fix_template_paths.py  – ajusta caminhos de templates após reorganização

• Edy Carlos – 23/05/2025
"""
from __future__ import annotations
import pathlib, re, shutil

# ──────────────────────────────────────────────────────────────
# 1) mapa   antigo -> novo
#    -----------------------------------------------------------
MAPPING: dict[str, str] = {
    # --- auth ---
    "login.html":                     "auth/login.html",
    "cadastro.html":                  "auth/cadastro.html",
    "esqueci_senha_cpf.html":         "auth/esqueci_senha_cpf.html",
    "reset_senha_cpf.html":           "auth/reset_senha_cpf.html",
    "cadastro_participante.html":     "auth/cadastro_participante.html",
    "cadastro_ministrante.html":      "auth/cadastro_ministrante.html",
    "cadastro_professor.html":        "auth/cadastro_professor.html",
    "cadastro_usuario.html":          "auth/cadastro_usuario.html",
    "cadastrar_cliente.html":         "auth/cadastrar_cliente.html",

    # --- dashboard ---
    "dashboard_admin.html":           "dashboard/dashboard_admin.html",
    "dashboard_participante.html":    "dashboard/dashboard_participante.html",
    "dashboard_ministrante.html":     "dashboard/dashboard_ministrante.html",
    "dashboard_professor.html":       "dashboard/dashboard_professor.html",
    "dashboard_cliente.html":         "dashboard/dashboard_cliente.html",
    "dashboard_superadmin.html":      "dashboard/dashboard_superadmin.html",

    # --- evento ---
    "criar_evento.html":              "evento/criar_evento.html",
    "configurar_evento.html":         "evento/configurar_evento.html",
    "listar_inscritos_evento.html":   "evento/listar_inscritos_evento.html",
    "eventos_disponiveis.html":       "evento/eventos_disponiveis.html",

    # --- inscrição ---
    "gerenciar_inscricoes.html":      "inscricao/gerenciar_inscricoes.html",
    "preencher_formulario.html":      "inscricao/preencher_formulario.html",
    "configurar_regras_inscricao.html":"inscricao/configurar_regras_inscricao.html",

    # --- oficina ---
    "criar_oficina.html":             "oficina/criar_oficina.html",
    "editar_oficina.html":            "oficina/editar_oficina.html",
    "feedback_oficina.html":          "oficina/feedback_oficina.html",

    # --- sorteio ---
    "criar_sorteio.html":             "sorteio/criar_sorteio.html",
    "gerenciar_sorteios.html":        "sorteio/gerenciar_sorteios.html",

    # --- trabalho / submissões ---
    "meus_trabalhos.html":            "trabalho/meus_trabalhos.html",
    "avaliar_trabalho.html":          "trabalho/avaliar_trabalho.html",
    "avaliar_trabalhos.html":         "trabalho/avaliar_trabalhos.html",
    "submeter_trabalho.html":         "trabalho/submeter_trabalho.html",
    "definir_status_resposta.html":   "trabalho/definir_status_resposta.html",
    "listar_respostas.html":          "trabalho/listar_respostas.html",
    "dar_feedback_resposta.html":     "trabalho/dar_feedback_resposta.html",
    "visualizar_resposta.html":       "trabalho/visualizar_resposta.html",

    # --- agendamento ---
    "criar_agendamento.html":         "agendamento/criar_agendamento.html",
    "editar_agendamento.html":        "agendamento/editar_agendamento.html",
    "configurar_agendamentos.html":   "agendamento/configurar_agendamentos.html",
    "configurar_horarios_agendamento.html":
                                      "agendamento/configurar_horarios_agendamento.html",
    "gerar_horarios_agendamento.html":"agendamento/gerar_horarios_agendamento.html",
    "eventos_agendamento.html":       "agendamento/eventos_agendamento.html",
    "relatorio_geral_agendamentos.html":
                                      "agendamento/relatorio_geral_agendamentos.html",
    "listar_agendamentos.html":       "agendamento/listar_agendamentos.html",
    "dashboard_agendamentos.html":    "agendamento/dashboard_agendamentos.html",
    "detalhes_agendamentos.html":     "agendamento/detalhes_agendamentos.html",
    "agendar_visita.html":            "agendamento/agendar_visita.html",
    "criar_evento_agendamento.html":  "agendamento/criar_evento_agendamento.html",
    "criar_periodo_agendamento.html": "agendamento/criar_periodo_agendamento.html",
    "editar_sala_visitacao.html":     "agendamento/editar_sala_visitacao.html",
    "listar_horarios_agendamento.html":"agendamento/listar_horarios_agendamento.html",
    "salas_visitacao.html":           "agendamento/salas_visitacao.html",
    "importar_agendamentos.html":     "agendamento/importar_agendamentos.html",

    # --- certificado ---
    "templates_certificado.html":     "certificado/templates_certificado.html",
    "upload_personalizacao_cert.html":"certificado/upload_personalizacao_cert.html",
    "usar_template.html":             "certificado/usar_template.html",
    "criar_template.html":            "certificado/criar_template.html",

    # --- formulário ---
    "criar_formulario.html":          "formulario/criar_formulario.html",
    "templates_formulario.html":      "formulario/templates_formulario.html",
    "editar_formulario.html":         "formulario/editar_formulario.html",
    "formularios.html":               "formulario/formularios.html",
    "formularios_participante.html":  "formulario/formularios_participante.html",
    "gerenciar_campos.html":          "formulario/gerenciar_campos.html",
    "gerenciar_campos_template.html": "formulario/gerenciar_campos_template.html",
    "editar_campo.html":              "formulario/editar_campo.html",

    # --- patrocinador ---
    "gerenciar_patrocinadores.html":  "patrocinador/gerenciar_patrocinadores.html",
    "listar_patrocinadores.html":     "patrocinador/listar_patrocinadores.html",
    "upload_material.html":           "patrocinador/upload_material.html",

    # --- check-in ---
    "checkin.html":                   "checkin/checkin.html",
    "checkin_qr_agendamento.html":    "checkin/checkin_qr_agendamento.html",
    "lista_checkins.html":            "checkin/lista_checkins.html",
    "confirmar_checkin.html":         "checkin/confirmar_checkin.html",
    "scan_qr.html":                   "checkin/scan_qr.html",

    # --- feedback ---
    "feedback.html":                  "feedback/feedback.html",

    # --- config ---
    "config_system.html":             "config/config_system.html",

    # --- relatorio ---
    "enviar_relatorio.html":          "relatorio/enviar_relatorio.html",

    # --- pagamento ---
    "pagamento_certo.html":           "pagamento/pagamento_certo.html",
    "pagamento_errado.html":          "pagamento/pagamento_errado.html",
}

# ──────────────────────────────────────────────────────────────
# 2) arquivos alvo
ROOT = pathlib.Path(__file__).resolve().parent
PY_FILES = [p for p in ROOT.rglob("*.py")
            if "venv" not in p.parts and "migrations" not in p.parts]

# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 3) regex  render_template('…')  /  render_template("…")
RE = re.compile(r'render_template\(\s*[\'"]([^/\'"]+\.html)[\'"]')

def replace_path(match: re.Match) -> str:
    tpl = match.group(1)
    new = MAPPING.get(tpl)
    return f'render_template("{new}")' if new else match.group(0)

# ──────────────────────────────────────────────────────────────
# 4) loop
changed_any = False
for file in PY_FILES:
    text = file.read_text(encoding="utf-8")
    new_text, n = RE.subn(replace_path, text)
    if n:
        shutil.copy(file, file.with_suffix(file.suffix + ".bak"))
        file.write_text(new_text, encoding="utf-8")
        print(f"🛠  {file.relative_to(ROOT)}  – {n} substituído(s)")
        changed_any = True

if not changed_any:
    print("Nenhum render_template() precisou de ajuste.")
else:
    print("\n✅  Concluído!  (backups *.bak criados)")

